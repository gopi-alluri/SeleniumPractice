package testNGPack;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class APITest {
	
	@BeforeTest
	public void beforeTest() {
		System.out.println("Before Test");
	}
	
	@AfterTest
	public void afterTest() {
		System.out.println("After Test");
	}
	
	@BeforeClass
	public void beforeClass() {
		System.out.println("Before Class APITest");
	}
	
	@AfterClass
	public void afterClass() {
		System.out.println("After Class APITest");
	}
	
	@Test(groups= {"smoke"}, enabled=false)
	public void login() {
		System.out.println("APITest: login");
	}
	
	@Test
	public void purchase() {
		System.out.println("APITest: purchase");
	}

}
