package testNGPack;

import org.testng.annotations.Test;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class WebTest {
	
	//@BeforeSuite
	public void beforeSuite() {
		System.out.println("Before Suite");
	}
	
	//@AfterSuite
	public void afterSuite() {
		System.out.println("After Suite");
	}
	
	
	//@BeforeMethod
	public void beforeMethod() {
		System.out.println("Before Method WebTest");
	}
	
	//@BeforeMethod
	public void afterMethod() {
		System.out.println("After Method WebTest");
	}
	
	@Test(groups= {"smoke"}, priority=1, dependsOnMethods= {"payment"})
	public void login() {
		System.out.println("WebTest: login");
	}
	
	@Test(priority=0)
	public void purchase() {
		System.out.println("WebTest: purchase");
	}
	
	@Test(timeOut=2000, groups= {"smoke"})
	public void payment() {
		System.out.println("WebTest: payment");
	}

}
