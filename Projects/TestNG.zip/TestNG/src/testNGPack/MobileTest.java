package testNGPack;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class MobileTest {
	
	@Parameters({"url","username"})
	@Test
	public void launchURL(@Optional String urlname, @Optional String username) {
		System.out.println("MobileTest: launch URL "+ urlname +" for User "+username);
	}
	
	@Test(dataProvider="getData")
	public void login(String username, String password) {
		System.out.println("MobileTest: login with Username "+username +" and password "+password);
	}
	
	@Test
	public void purchase() {
		System.out.println("MobileTest: purchase");
		Assert.assertTrue(false);
	}
	
	@Test
	public void payment() {
		System.out.println("MobileTest: payment");
	}
	
	@DataProvider
	public String[][] getData(){
		String[][] loginData = new String[3][2];
		loginData[0][0] = "user1";
		loginData[0][1] = "password1";
		loginData[1][0] = "user2";
		loginData[1][1] = "password2";
		loginData[2][0] = "user3";
		loginData[2][1] = "password3";
		
		return loginData;
	}

}
