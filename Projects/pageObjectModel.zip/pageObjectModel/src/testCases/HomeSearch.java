package testCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import objectRepository.RediffHomePage;
import objectRepository.RediffLoginPage;

public class HomeSearch {
	
	@Test
	public void login() throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver.exe" );
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.rediff.com/");
		RediffHomePage homePage = new RediffHomePage(driver);
		Thread.sleep(3000);
		homePage.getCompany().sendKeys("mobile");
		homePage.getSearch().click();	
	}
}
