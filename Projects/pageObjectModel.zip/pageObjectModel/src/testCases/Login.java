package testCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import objectRepository.RediffLoginPage;

public class Login {
	
	@Test
	public void login() throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver.exe" );
		WebDriver driver = new ChromeDriver();
		driver.get("https:/mail.rediff.com/cgi-bin/login.cgi");
		driver.manage().window().maximize();
		RediffLoginPage loginPage = new RediffLoginPage(driver);
		Thread.sleep(5000);
		loginPage.getUsername().sendKeys("user1");
		Thread.sleep(3000);
		loginPage.getPassword().sendKeys("Password1");
		Thread.sleep(3000);
		loginPage.getSubmit().click();
		
	}

}
