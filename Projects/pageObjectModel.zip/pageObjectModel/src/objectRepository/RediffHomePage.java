package objectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RediffHomePage {
	WebDriver driver;
	public RediffHomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	By company = By.xpath("//input[@id='srchword']");
	By search = By.className("newsrchbtn");

	public WebElement getCompany() {
		return driver.findElement(company);
	}

	public WebElement getSearch() {
		return driver.findElement(search);
	}

}
