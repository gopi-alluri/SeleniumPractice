package alpha;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LogDemo {
	
	public static Logger log = LogManager.getLogger(LogDemo.class.getName());
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		log.debug("LogDemo: clicked on button");
		log.info("LogDemo: logged in successfully");
		log.error("LogDemo: login failed");
		log.fatal("LogDemo: page not found");
	}

}
