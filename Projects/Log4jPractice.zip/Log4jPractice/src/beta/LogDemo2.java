package beta;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LogDemo2 {
	
	public static Logger log = LogManager.getLogger(LogDemo2.class.getName());
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		log.debug("LogDemo2: clicked on button");
		log.info("LogDemo2: logged in successfully");
		log.error("LogDemo2: login failed");
		log.fatal("LogDemo2: page not found");
	}

}
