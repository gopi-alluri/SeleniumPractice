package com.mycompany.app.my_app;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class WebTest {
	
	// @Test
	public void login() {
		System.out.println("WebTest: login");
	}
	
	@Test
	public void purchase() {
		System.out.println("WebTest: purchase");
	}

}
