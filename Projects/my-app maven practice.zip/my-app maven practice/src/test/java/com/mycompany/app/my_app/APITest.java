package com.mycompany.app.my_app;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class APITest {
	
	@Test
	public void login() {
		System.out.println("APITest: login");
	}
	
	@Test
	public void purchase() {
		System.out.println("APITest: purchase");
	}

}
